function plotGraph(dataPoints1,dataPoints2,dataPoints3)
{
  var x = [];
  var y = [];
  var z = [];
  var col;

  {col = 'blue';}


  var trace1 = {type: 'scatter3d',
  mode:'lines+markers',
  name:'Running',
  marker:{color:col}};
  var data = [];

  for (i in dataPoints1)
  {
    for(point in dataPoints1[i])
    {
      //console.log(dataPoints[i][point].x);
      x.push(dataPoints1[i][point].x);
      y.push(dataPoints1[i][point].y);
      z.push(dataPoints1[i][point].z);
    }

    // trace1['x'] = x;
    // trace1['y'] = y;
    // trace1['z'] = z;
    // //console.log(x.length);
    // data.push(trace1);
    // x = [];
    // y = [];
    // z = [];
  }
    trace1['x'] = x;
    trace1['y'] = y;
    trace1['z'] = z;
    //console.log(x.length);
    data.push(trace1);
    x = [];
    y = [];
    z = [];
  //Plotly.newPlot(myDiv, data);

  {col = 'red';}
  var trace2 = {type: 'scatter3d',
  mode:'lines+markers',
  name:'Jumping',
  marker:{color:col}};
  //var data = [];

  for (i in dataPoints2)
  {
    for(point in dataPoints2[i])
    {
      //console.log(dataPoints[i][point].x);
      x.push(dataPoints2[i][point].x);
      y.push(dataPoints2[i][point].y);
      z.push(dataPoints2[i][point].z);
    }

    // trace2['x'] = x;
    // trace2['y'] = y;
    // trace2['z'] = z;
    // //console.log(x.length);
    // data.push(trace2);
    // x = [];
    // y = [];
    // z = [];
  }
    trace2['x'] = x;
    trace2['y'] = y;
    trace2['z'] = z;
    //console.log(x.length);
    data.push(trace2);
    x = [];
    y = [];
    z = [];
  //Plotly.newPlot(myDiv, data);

  {col = 'green';}
  var trace3 = {type: 'scatter3d',
  mode:'lines+markers',
  name:'Walking',
  marker:{color:col}};
  //var data = [];

  for (i in dataPoints3)
  {
    for(point in dataPoints3[i])
    {
      //console.log(dataPoints[i][point].x);
      x.push(dataPoints3[i][point].x);
      y.push(dataPoints3[i][point].y);
      z.push(dataPoints3[i][point].z);
    }

    // trace3['x'] = x;
    // trace3['y'] = y;
    // trace3['z'] = z;
    // //console.log(x.length);
    // data.push(trace3);
    // x = [];
    // y = [];
    // z = [];
  }
    trace3['x'] = x;
    trace3['y'] = y;
    trace3['z'] = z;
    //console.log(x.length);
    data.push(trace3);
    x = [];
    y = [];
    z = [];

  Plotly.newPlot(myDiv, data);

}
