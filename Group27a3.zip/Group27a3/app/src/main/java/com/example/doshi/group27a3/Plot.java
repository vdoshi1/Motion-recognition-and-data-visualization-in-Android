package com.example.doshi.group27a3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.gson.Gson;

import java.util.ArrayList;

public class Plot extends AppCompatActivity {
    WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plot);
        web = (WebView)findViewById(R.id.myweb_id);
        WebSettings webSettings= web.getSettings();
        webSettings.setJavaScriptEnabled(true);

        AssetHelper myhelp = new AssetHelper(this);

        ArrayList<ArrayList<AccValues>> walk = myhelp.getarray('W');
        ArrayList<ArrayList<AccValues>> run = myhelp.getarray('R');
        ArrayList<ArrayList<AccValues>> jump = myhelp.getarray('J');
        Gson gson = new Gson();
        final String jumpJson = gson.toJson(jump);
        final String runJson = gson.toJson(run);
        final String walkJson = gson.toJson(walk);

        web.loadUrl("file:///android_asset/"+"html/plot.html");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                view.loadUrl("javascript:plotGraph("+runJson+", "+jumpJson+", "+walkJson+")");
            }
        });

        web.addJavascriptInterface(new WebAppInterface(this), "Android");
   }
}
