package com.example.doshi.group27a3;

/**
 * Created by Doshi on 19-Apr-18.
 */
        import android.app.AlertDialog;
        import android.content.Context;
        import android.webkit.JavascriptInterface;
        import android.widget.Toast;

/**
 * Created by nidhi on 4/12/2018.
 */

public class WebAppInterface {
    Context mContext;

    /** Instantiate the interface and set the context */
    WebAppInterface(Context c) {
        mContext = c;
    }

    /** Show a toast from the web page */
    @JavascriptInterface
    public void showToast(String toast) {
        Toast.makeText(mContext, toast, Toast.LENGTH_SHORT).show();
    }

    public void showDialog(String dialogMsg){
        AlertDialog alertDialog = new AlertDialog.Builder(mContext).create();

        // Setting Dialog Title
        //alertDialog.setTitle("Javascript triggered..");

        // Setting Dialog Message
        // alertDialog.setMessage(dialogMsg);

        // Setting alert dialog icon
        //alertDialog.setIcon((status) ? R.drawable.success : R.drawable.fail);

        Toast.makeText(mContext, "Dialog dismissed!", Toast.LENGTH_SHORT).show();
        // Setting OK Button
//        alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
//            public void onClick(DialogInterface dialog, int which) {
//                Toast.makeText(mContext, "Dialog dismissed!", Toast.LENGTH_SHORT).show();
//            }
//        });

        // Showing Alert Message
        alertDialog.show();
    }
}

