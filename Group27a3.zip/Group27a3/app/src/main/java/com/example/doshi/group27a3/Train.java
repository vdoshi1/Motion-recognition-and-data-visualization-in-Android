package com.example.doshi.group27a3;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.Vector;

import libsvm.svm;
import libsvm.svm_model;
import libsvm.svm_node;
import libsvm.svm_parameter;
import libsvm.svm_problem;


import static com.example.doshi.group27a3.AssetHelper.table;

public class Train extends AppCompatActivity {
    private svm_parameter parameter;
    private svm_problem data_values;
    private int cross_validation;
    private int nr_fold;
    private double accuracy_value = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_train);
        TextView tv = (TextView) findViewById(R.id.accuracy_id);
        try {
            parameters();
            setData();
            String error_msg = svm.svm_check_parameter(data_values, parameter);
            if (error_msg != null)
                Toast.makeText(getBaseContext(), error_msg, Toast.LENGTH_LONG).show();
            if (cross_validation != 0)
                crossValidation();
            else {
                svm_model model = svm.svm_train(data_values, parameter);
            }

            tv.setText("" + accuracy_value);

        } catch (Exception ex) {
            Toast.makeText(getBaseContext(), ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void parameters() {
        parameter = new svm_parameter();
        parameter.svm_type = svm_parameter.C_SVC;
        parameter.kernel_type = svm_parameter.POLY;
        parameter.eps = 1e-2;
        cross_validation = 5;
        nr_fold = 5;
        parameter.degree = 2;
        parameter.gamma = 0.007;
        parameter.coef0 = 0;
        parameter.nu = 0.5;
        parameter.cache_size = 100;
        parameter.C = 10000;
    }

    public void setData() throws IOException {

        AssetHelper svmhelper = new AssetHelper(this);
        SQLiteDatabase db = svmhelper.getWritableDatabase();
        Cursor csr = db.query(table,null,null,null,null,null,null);
        Vector<Double> vy = new Vector<Double>();
        Vector<svm_node[]> vx = new Vector<svm_node[]>();
        int max_index = 0;

        while (csr.moveToNext()) {
            if(csr.getPosition()<20)
                vy.addElement((double)+1);
            else if((csr.getPosition()>=20)&&(csr.getPosition()<40))
                vy.addElement((double)+2);
            else if((csr.getPosition()>=40)&&(csr.getPosition()<60))
                vy.addElement((double)+3);

            svm_node[] nd = new svm_node[150];
            for(int j=0;j<50;j++) {
                double x = csr.getDouble(csr.getColumnIndex(String.format("acc_x%d", j+1)));
                double y = csr.getDouble(csr.getColumnIndex(String.format("acc_y%d", j+1)));
                double z = csr.getDouble(csr.getColumnIndex(String.format("acc_z%d", j+1)));

                System.out.println(String.format("row %d x%f  y%f  z%f",j,x,y,z));
                nd[(0 + 3*j)] = new svm_node();
                nd[(0 + 3*j)].index = 1 + 3*j;
                nd[(0 + 3*j)].value = x;


                nd[(1 + 3*j)] = new svm_node();
                nd[(1 + 3*j)].index = 2 + 3*j;
                nd[(1 + 3*j)].value = y;

                nd[(2 + 3*j)] = new svm_node();
                nd[(2 + 3*j)].index = 3+3*j;
                nd[(2 + 3*j)].value = z;
            }

            if (150 > 0) max_index = Math.max(max_index, nd[149].index);
            vx.addElement(nd);
        }

        data_values = new svm_problem();
        System.out.println("------------------------------->>>>>>>>>>>"+data_values);
        data_values.l = vy.size();
        data_values.x = new svm_node[data_values.l][];

        for (int i = 0; i < data_values.l; i++)
            data_values.x[i] = vx.elementAt(i);
        data_values.y = new double[data_values.l];
        for (int i = 0; i < data_values.l; i++)
            data_values.y[i] = vy.elementAt(i);
    }

    private void crossValidation() {
        int i;
        int total_correct = 0;
        double[] target = new double[data_values.l];

        svm.svm_cross_validation(data_values, parameter, nr_fold, target);
        total_correct = 0;

        for (i = 0; i < data_values.l; i++)
            if (target[i] == data_values.y[i])
                ++total_correct;
        accuracy_value = 100.0 * total_correct / data_values.l;
        System.out.println("" + data_values.l +"total"+ total_correct);
        Toast.makeText(getBaseContext(), "Cross Validation Accuracy = " + 100.0 * total_correct / data_values.l + "%\n", Toast.LENGTH_LONG).show();
    }
}



