package com.example.doshi.group27a3;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;

import java.io.File;

import static java.sql.Types.REAL;

/**
 * Created by Doshi on 17-Apr-18.
 */

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(Context context, String dbName) {
        super(context, Environment.getExternalStorageDirectory()
                + File.separator + "Android"
                + File.separator + "data"
                + "/CSE535_ASSIGNMENT3"
                + File.separator
                + dbName, null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
       // db.execSQL("DROP TABLE IF EXISTS Activity");

    }

    public String create_table()
    {
        String cmd = "CREATE TABLE IF NOT EXISTS Activity (ID INTEGER PRIMARY KEY AUTOINCREMENT";
        for(int i=0;i<50;i++)
        {
            cmd = cmd + String.format(", acc_x%d REAL, acc_y%d REAL, acc_z%d REAL",i+1,i+1,i+1);
        }
        cmd = cmd + ", Label TEXT)";
        return cmd;
    }
}
