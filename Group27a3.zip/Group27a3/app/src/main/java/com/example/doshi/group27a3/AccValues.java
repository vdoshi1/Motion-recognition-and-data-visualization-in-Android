package com.example.doshi.group27a3;

public class AccValues {
    public double x;
    public double y;
    public double z;

    public AccValues(double x, double y, double z){
        this.x = x;
        this.y = y;
        this.z = z;
    }

}
