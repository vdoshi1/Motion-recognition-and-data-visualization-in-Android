package com.example.doshi.group27a3;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.File;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    Button start;
    Button clear;
    Button plot;
    Button train;
    TextView activity;
    TextView count;
    TextView record;
    private SensorManager accManager;
    private Sensor acc;
    public float last_x,last_y,last_z;
    public int count_num=0,act_num=0;
    public SQLiteDatabase db;
    ContentValues values;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        start = (Button)findViewById(R.id.start_id);
        clear = (Button)findViewById(R.id.clr_db);
        plot = (Button)findViewById(R.id.plt_id);
        train = (Button)findViewById(R.id.train_id);
        activity = (TextView)findViewById(R.id.activity_id);
        count = (TextView)findViewById(R.id.count_id);
        record = (TextView)findViewById(R.id.record_id);

        accManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        acc = accManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        accManager.registerListener(this, acc , SensorManager.SENSOR_DELAY_NORMAL);

        count.setText(Integer.toString(count_num));
        activity.setText("W");
        record.setText("OFF");




        final DBHelper helper = new DBHelper(this, "Group27.db");
        db = helper.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS Activity");
        db.execSQL(helper.create_table());



        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                                count_num++;
                                if(count_num == 21)
                                {
                                    count_num=1;
                                    act_num++;
                                }
                                if(act_num>2)
                                {
                                    record.setText("FINISH");
                                    return;
                                }
                                values = new ContentValues();

                                record.setText("REC ON");
                               new Thread(new Runnable() {
                           @Override
                           public void run() {
                               for(int i = 0; i<50; i++)
                               {
                                   //add data
                                   try
                                   {
                                       Thread.sleep(100);
                                       values.put(String.format("acc_x%d",i+1), last_x);
                                       values.put(String.format("acc_y%d",i+1), last_y);
                                       values.put(String.format("acc_z%d",i+1), last_z);

                                       System.out.println(String.format("Num :   %d  %f \t %f \t %f",i,last_x,last_y,last_z));

                                   }
                                   catch (InterruptedException e)
                                   {
                                       Log.i("INFO","Couldn't sleep");
                                   }
                               }


                               if(act_num == 0)
                                   values.put("Label","Walking");
                               else if(act_num==1)
                                   values.put("Label","Running");
                               else if(act_num==2)
                                   values.put("Label","Jumping");




                               runOnUiThread(new Runnable() {
                                   @Override
                                   public void run() {
                                       System.out.println(Long.toString(helper.getWritableDatabase().insert("Activity",null,values)));

                                       count.setText(Integer.toString(count_num));
                                       record.setText("REC DONE");
                                       if(act_num==1)
                                           activity.setText("R");
                                       else if(act_num==2)
                                           activity.setText("J");

                                   }
                               });

                           }
                       }).start();


                   }


        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.execSQL("DROP TABLE IF EXISTS Activity");

                db.execSQL(helper.create_table());
                count_num=0;
                act_num=0;
                count.setText(Integer.toString(count_num));
                activity.setText("W");
                record.setText("OFF");
            }
        });

        plot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent plot = new Intent(MainActivity.this,Plot.class);
                startActivity(plot);
            }
        });

        train.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent train = new Intent(MainActivity.this, Train.class);
                startActivity(train);
            }
        });

   }


    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        Sensor mySensor = sensorEvent.sensor;
        if (mySensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            last_x = sensorEvent.values[0];
            last_y = sensorEvent.values[1];
            last_z = sensorEvent.values[2];
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}


