package com.example.doshi.group27a3;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

import java.util.ArrayList;

/**
 * Created by Doshi on 19-Apr-18.
 */

public class AssetHelper extends SQLiteAssetHelper {
    public static final String DATABASE_NAME = "Group27.db";
    public static final int DATABASE_VERSION = 1;
    public static final String table="Activity";

    public AssetHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public ArrayList<ArrayList<AccValues>> getarray(char act)
    {
        ArrayList<ArrayList<AccValues>> temp = new ArrayList<ArrayList<AccValues>>();
        ArrayList<AccValues> oned;
        AccValues accvalues;
        SQLiteDatabase db = getWritableDatabase();
        Cursor csr = db.query(table,null,null,null,null,null,null);

        if(act == 'W')
        {
            csr.moveToFirst();
        }

        else if(act == 'R')
        {
            csr.moveToPosition(20);
        }

        else if(act == 'J')
        {
            csr.moveToPosition(40);
        }
        for(int i=0;i<20;i++)
        {
            oned = new ArrayList<AccValues>();

            for(int j=1;j<=50;j++)
            {
                double x = csr.getDouble(csr.getColumnIndex(String.format("acc_x%d",j)));
                double y= csr.getDouble(csr.getColumnIndex(String.format("acc_y%d",j)));
                double z= csr.getDouble(csr.getColumnIndex(String.format("acc_z%d",j)));
                accvalues = new AccValues(x,y,z);
                oned.add(accvalues);
            }

            temp.add(oned);
            csr.moveToNext();
        }
        return temp;
    }

}
